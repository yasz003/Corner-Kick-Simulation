import numpy as np
import json
import pickle
import pandas as pd
import csv
import os
from scipy.integrate import solve_ivp
import time
from concurrent.futures import ProcessPoolExecutor
import multiprocessing as mp
from optimization import optimize_corner_kick_parameters

# 全局列表用于存储进球位置和参数
goal_data = []

def save_goal_data():
    """保存所有进球数据到CSV文件"""
    if not goal_data:
        print("没有记录到任何进球")
        return
    
    # 创建DataFrame并保存为CSV
    df = pd.DataFrame(goal_data)
    filename = 'corner_kick_goals.csv'
    df.to_csv(filename, index=False)
    print(f"已将{len(goal_data)}个进球位置及参数数据保存至 {filename}")
    print(f"数据包含: 球速(ball_speed)、仰角(theta)、水平角(phi)、旋转速率(omega_z)、进球位置(y_pos, z_pos)和是否接近球门柱(is_near_post)")

def main():
    global goal_data
    
    print("Starting corner kick optimization simulation...")
    results = optimize_corner_kick_parameters()
    
    if results is None:
        print("Optimization failed to find valid solutions.")
        return
    
    optimal_params, sim_goal_data = results
    
    # 收集所有进球数据
    goal_data.extend(sim_goal_data)
    
    print("\nOptimization completed successfully!")
    
    # 模拟结束后保存进球数据
    save_goal_data()

if __name__ == "__main__":
    main()