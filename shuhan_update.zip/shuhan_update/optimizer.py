from scipy.optimize import differential_evolution
import multiprocessing as mp
import numpy as np
import time
from soccer_physics import simulate_corner_kick
from config import PARAMETER_BOUNDS  # 从 config 导入参数范围
# 直接导入预测函数
from calibration.calibration_draw import best_predict_cd, best_predict_cm

# 显示优化参数范围
print("\n优化参数范围:")
print(f"  球速: {PARAMETER_BOUNDS[0][0]}-{PARAMETER_BOUNDS[0][1]} m/s")
print(f"  仰角: {PARAMETER_BOUNDS[1][0]}-{PARAMETER_BOUNDS[1][1]} 度")
print(f"  水平角: {PARAMETER_BOUNDS[2][0]}-{PARAMETER_BOUNDS[2][1]} 度")
print(f"  z轴角速度: {PARAMETER_BOUNDS[3][0]}-{PARAMETER_BOUNDS[3][1]} rad/s")

def optimize_corner_kick():
    """使用差分进化算法优化角球参数"""
    print("\n开始角球优化计算...")
    start_time = time.time()
    
    def objective_function(params):
        ball_speed, theta, phi, omega_z = params
        # 创建角速度向量 (只在z轴方向)
        omega = [0, 0, omega_z]
        
        # 使用校准模型进行模拟
        is_goal, is_near_post, flight_time, min_distance, goal_position = simulate_corner_kick(
            ball_speed, theta, phi, omega,
            predict_cd_func=best_predict_cd,  # 使用导入的函数
            predict_cm_func=best_predict_cm   # 使用导入的函数
        )
        
        # 如果是目标附近的进球，返回飞行时间（越小越好）
        if is_goal and is_near_post:
            return flight_time
        # 如果是进球但不在目标区域附近，给予小惩罚
        elif is_goal:
            return flight_time + 5.0
        # 如果不是进球，返回大惩罚值和到目标的距离
        else:
            return 20.0 + min_distance

    # 使用差分进化算法
    result = differential_evolution(
        objective_function, 
        PARAMETER_BOUNDS,
        popsize=32,  # 增加种群大小以利用更多CPU核心
        maxiter=20,
        tol=0.01,
        mutation=(0.5, 1.0),
        recombination=0.7,
        workers=-1,  # 使用所有可用CPU核心
        updating='deferred'  # 使用延迟更新策略提高并行效率
    )
    
    end_time = time.time()
    print(f"\n优化完成，耗时: {end_time - start_time:.2f} 秒")
    
    return result.x, result.fun

# 使用multiprocessing进行并行计算
def parallel_grid_search(parameter_combinations):
    # 明确指定32个进程以匹配您的32个vCPU
    pool = mp.Pool(processes=32)
    results = pool.map(evaluate_params, parameter_combinations)
    pool.close()
    pool.join()
    return results

def evaluate_params(params):
    """评估单组参数"""
    ball_speed, theta, phi, omega_z = params
    # 创建角速度向量 (只在z轴方向)
    omega = [0, 0, omega_z]
    
    # 使用校准模型进行模拟
    is_goal, is_near_post, flight_time, min_distance, goal_position = simulate_corner_kick(
        ball_speed, theta, phi, omega,
        predict_cd_func=best_predict_cd,  # 使用导入的函数 
        predict_cm_func=best_predict_cm   # 使用导入的函数
    )
    
    result = {
        'params': params,
        'is_goal': is_goal,
        'is_near_post': is_near_post,
        'flight_time': flight_time,
        'min_distance': min_distance,
        'goal_position': goal_position if is_goal else None
    }
    
    return result