# 在您的其他文件中
from calibration_draw import load_calibration_models

# 加载模型
predict_cd, predict_cm, models_info = load_calibration_models()

# 使用模型进行预测
sp_value = 0.25
cd = predict_cd(sp_value)
cm = predict_cm(sp_value)
print(f"At sp={sp_value}: cd={cd:.6f}, cm={cm:.6f}")

# 查看哪种模型是最佳模型
print(f"Best model for cd: {models_info['cd_best_model_name']}")
print(f"Best model for cm: {models_info['cm_best_model_name']}")