import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit
from scipy.interpolate import UnivariateSpline, interp1d
from sklearn.preprocessing import PolynomialFeatures
from sklearn.linear_model import Ridge
from sklearn.pipeline import make_pipeline
from sklearn.metrics import mean_squared_error, r2_score
import pickle

# Input data
sp_observed = np.array([0.00, 0.05, 0.10, 0.15, 0.20, 0.25, 0.30, 0.35, 0.40, 0.45, 0.50])
cd_observed = np.array([0.39, 0.32, 0.31, 0.30, 0.28, 0.27, 0.29, 0.32, 0.35, 0.38, 0.41])
cm_observed = np.array([0.03, -0.05, -0.09, -0.05, -0.02, 0.02, 0.11, 0.16, 0.19, 0.21, 0.24])

# Create a finer grid for predictions
sp_fine = np.linspace(0, 0.5, 1000)

# === Method 1: Polynomial Regression with Regularization ===
def polynomial_regression(x, y, degree, alpha=0.01, x_pred=None):
    """
    Fit polynomial regression with regularization
    
    Parameters:
    -----------
    x : array-like, input data
    y : array-like, target values
    degree : int, polynomial degree
    alpha : float, regularization strength
    x_pred : array-like, prediction points (optional)
    
    Returns:
    --------
    model : fitted model
    y_pred : predicted values at x_pred points
    mse : mean squared error of the fit
    r2 : R² score of the fit
    """
    if x_pred is None:
        x_pred = x
        
    # Reshape for sklearn
    x_reshaped = x.reshape(-1, 1)
    x_pred_reshaped = x_pred.reshape(-1, 1)
    
    # Create model (Pipeline with polynomial features and ridge regression)
    model = make_pipeline(
        PolynomialFeatures(degree),
        Ridge(alpha=alpha)
    )
    
    # Fit model
    model.fit(x_reshaped, y)
    
    # Generate predictions
    y_pred = model.predict(x_pred_reshaped)
    y_fit = model.predict(x_reshaped)
    
    # Compute metrics
    mse = mean_squared_error(y, y_fit)
    r2 = r2_score(y, y_fit)
    
    return model, y_pred, mse, r2

# === Method 2: Cubic Spline Interpolation with Smoothing ===
def spline_interpolation(x, y, s=0.0, x_pred=None):
    """
    Fit cubic spline with smoothing
    
    Parameters:
    -----------
    x : array-like, input data
    y : array-like, target values
    s : float, smoothing factor (0 = exact interpolation)
    x_pred : array-like, prediction points (optional)
    
    Returns:
    --------
    spline : fitted spline object
    y_pred : predicted values at x_pred points
    mse : mean squared error of the fit
    r2 : R² score of the fit
    """
    if x_pred is None:
        x_pred = x
    
    # Fit spline
    spline = UnivariateSpline(x, y, k=3, s=s)
    
    # Generate predictions
    y_pred = spline(x_pred)
    y_fit = spline(x)
    
    # Compute metrics
    mse = mean_squared_error(y, y_fit)
    r2 = r2_score(y, y_fit)
    
    return spline, y_pred, mse, r2

# === Method 3: Custom Parametric Model ===
def cd_model(x, a, b, c, d, e):
    """Parametric model for drag coefficient"""
    return a + b*x + c*x**2 + d*np.exp(-50*(x-0.25)**2) + e*np.exp(-100*(x-0.5)**2)

def cm_model(x, a, b, c, d, e, f):
    """Parametric model for moment coefficient"""
    return a + b*x + c*x**2 + d*x**3 + e*np.exp(-30*(x-0.1)**2) + f*np.exp(-50*(x-0.3)**2)

def parametric_model_fit(x, y, model_func, x_pred=None, p0=None):
    """
    Fit a parametric model using curve_fit
    
    Parameters:
    -----------
    x : array-like, input data
    y : array-like, target values
    model_func : function, the parametric model to fit
    x_pred : array-like, prediction points (optional)
    p0 : array-like, initial parameter guess (optional)
    
    Returns:
    --------
    params : fitted parameter values
    y_pred : predicted values at x_pred points
    mse : mean squared error of the fit
    r2 : R² score of the fit
    """
    if x_pred is None:
        x_pred = x
    
    # Fit the model
    params, _ = curve_fit(model_func, x, y, p0=p0, maxfev=10000)
    
    # Generate predictions
    y_pred = model_func(x_pred, *params)
    y_fit = model_func(x, *params)
    
    # Compute metrics
    mse = mean_squared_error(y, y_fit)
    r2 = r2_score(y, y_fit)
    
    return params, y_pred, mse, r2

# ----------------------------------------------------
# Calibration for c_d(sp)
# ----------------------------------------------------

# 1. Polynomial Regression for c_d
cd_poly_model, cd_poly_pred, cd_poly_mse, cd_poly_r2 = polynomial_regression(
    sp_observed, cd_observed, degree=5, alpha=0.01, x_pred=sp_fine
)

# 2. Spline for c_d
cd_spline, cd_spline_pred, cd_spline_mse, cd_spline_r2 = spline_interpolation(
    sp_observed, cd_observed, s=0.001, x_pred=sp_fine
)

# 3. Parametric model for c_d
cd_param_p0 = [0.3, 0, 0.5, -0.05, 0.1]  # Initial guess
cd_param, cd_param_pred, cd_param_mse, cd_param_r2 = parametric_model_fit(
    sp_observed, cd_observed, cd_model, x_pred=sp_fine, p0=cd_param_p0
)

# Select best model for c_d based on R² score
cd_models = {
    'Polynomial Regression': (cd_poly_model, cd_poly_pred, cd_poly_mse, cd_poly_r2),
    'Cubic Spline': (cd_spline, cd_spline_pred, cd_spline_mse, cd_spline_r2),
    'Parametric Model': (cd_param, cd_param_pred, cd_param_mse, cd_param_r2)
}

cd_best_model_name = max(cd_models, key=lambda k: cd_models[k][3])
cd_best_model = cd_models[cd_best_model_name]

# ----------------------------------------------------
# Calibration for c_m(sp)
# ----------------------------------------------------

# 1. Polynomial Regression for c_m
cm_poly_model, cm_poly_pred, cm_poly_mse, cm_poly_r2 = polynomial_regression(
    sp_observed, cm_observed, degree=5, alpha=0.01, x_pred=sp_fine
)

# 2. Spline for c_m
cm_spline, cm_spline_pred, cm_spline_mse, cm_spline_r2 = spline_interpolation(
    sp_observed, cm_observed, s=0.001, x_pred=sp_fine
)

# 3. Parametric model for c_m
cm_param_p0 = [0, 0.5, 0, 0, -0.1, 0.1]  # Initial guess
cm_param, cm_param_pred, cm_param_mse, cm_param_r2 = parametric_model_fit(
    sp_observed, cm_observed, cm_model, x_pred=sp_fine, p0=cm_param_p0
)

# Select best model for c_m based on R² score
cm_models = {
    'Polynomial Regression': (cm_poly_model, cm_poly_pred, cm_poly_mse, cm_poly_r2),
    'Cubic Spline': (cm_spline, cm_spline_pred, cm_spline_mse, cm_spline_r2),
    'Parametric Model': (cm_param, cm_param_pred, cm_param_mse, cm_param_r2)
}

cm_best_model_name = max(cm_models, key=lambda k: cm_models[k][3])
cm_best_model = cm_models[cm_best_model_name]

# ----------------------------------------------------
# Result Visualization
# ----------------------------------------------------

plt.figure(figsize=(18, 10))

# Plot c_d(sp) calibration
plt.subplot(2, 1, 1)
plt.scatter(sp_observed, cd_observed, color='red', label='Observed Data')
plt.plot(sp_fine, cd_poly_pred, 'b-', linewidth=1, label=f'Polynomial (R²={cd_poly_r2:.4f})')
plt.plot(sp_fine, cd_spline_pred, 'g-', linewidth=1, label=f'Spline (R²={cd_spline_r2:.4f})')
plt.plot(sp_fine, cd_param_pred, 'm-', linewidth=1, label=f'Parametric (R²={cd_param_r2:.4f})')
plt.plot(sp_fine, cd_models[cd_best_model_name][1], 'k--', linewidth=2, label=f'Best: {cd_best_model_name}')
plt.xlabel('Space Point (sp)')
plt.ylabel('Drag Coefficient (c_d)')
plt.title('Calibration of c_d(sp)')
plt.grid(True)
plt.legend()

# Plot c_m(sp) calibration
plt.subplot(2, 1, 2)
plt.scatter(sp_observed, cm_observed, color='red', label='Observed Data')
plt.plot(sp_fine, cm_poly_pred, 'b-', linewidth=1, label=f'Polynomial (R²={cm_poly_r2:.4f})')
plt.plot(sp_fine, cm_spline_pred, 'g-', linewidth=1, label=f'Spline (R²={cm_spline_r2:.4f})')
plt.plot(sp_fine, cm_param_pred, 'm-', linewidth=1, label=f'Parametric (R²={cm_param_r2:.4f})')
plt.plot(sp_fine, cm_models[cm_best_model_name][1], 'k--', linewidth=2, label=f'Best: {cm_best_model_name}')
plt.xlabel('Space Point (sp)')
plt.ylabel('Moment Coefficient (c_m)')
plt.title('Calibration of c_m(sp)')
plt.grid(True)
plt.legend()

plt.tight_layout()
plt.savefig('calibration_results.png', dpi=300)
plt.show()

# ----------------------------------------------------
# Create Prediction Functions
# ----------------------------------------------------

def predict_cd(sp, method='best'):
    """
    Predict drag coefficient at given space point
    
    Parameters:
    -----------
    sp : float or array-like, space point
    method : str, prediction method ('best', 'polynomial', 'spline', 'parametric')
    
    Returns:
    --------
    cd : float or array-like, predicted drag coefficient
    """
    sp_array = np.atleast_1d(sp)
    
    if method == 'best':
        method = cd_best_model_name
    
    if method == 'Polynomial Regression':
        sp_reshaped = sp_array.reshape(-1, 1)
        cd = cd_poly_model.predict(sp_reshaped)
    elif method == 'Cubic Spline':
        cd = cd_spline(sp_array)
    elif method == 'Parametric Model':
        cd = cd_model(sp_array, *cd_param)
    else:
        raise ValueError(f"Unknown method: {method}")
    
    return cd[0] if len(cd) == 1 else cd

def predict_cm(sp, method='best'):
    """
    Predict moment coefficient at given space point
    
    Parameters:
    -----------
    sp : float or array-like, space point
    method : str, prediction method ('best', 'polynomial', 'spline', 'parametric')
    
    Returns:
    --------
    cm : float or array-like, predicted moment coefficient
    """
    sp_array = np.atleast_1d(sp)
    
    if method == 'best':
        method = cm_best_model_name
    
    if method == 'Polynomial Regression':
        sp_reshaped = sp_array.reshape(-1, 1)
        cm = cm_poly_model.predict(sp_reshaped)
    elif method == 'Cubic Spline':
        cm = cm_spline(sp_array)
    elif method == 'Parametric Model':
        cm = cm_model(sp_array, *cm_param)
    else:
        raise ValueError(f"Unknown method: {method}")
    
    return cm[0] if len(cm) == 1 else cm

# ----------------------------------------------------
# 保存模型和导出最佳预测函数
# ----------------------------------------------------

# 这些函数和变量将在导入时直接可用
best_predict_cd = predict_cd  # 使用已定义的最佳模型预测函数
best_predict_cm = predict_cm  # 使用已定义的最佳模型预测函数
best_cd_model_name = cd_best_model_name
best_cm_model_name = cm_best_model_name

def save_best_models(filename='calibration_models.pkl'):
    """保存最佳校准模型到文件"""
    models_to_save = {
        'cd_best_model_name': cd_best_model_name,
        'cd_models': cd_models,
        'cm_best_model_name': cm_best_model_name,
        'cm_models': cm_models,
        # 保存其他可能需要的信息
        'sp_observed': sp_observed,
        'cd_observed': cd_observed,
        'cm_observed': cm_observed
    }
    
    with open(filename, 'wb') as f:
        pickle.dump(models_to_save, f)
    
    print(f"\nModels successfully saved to {filename}")

def load_calibration_models(filename='calibration_models.pkl'):
    """从文件加载校准模型"""
    with open(filename, 'rb') as f:
        models_data = pickle.load(f)
    
    # 重建预测函数
    def loaded_predict_cd(sp, method='best'):
        """使用加载的模型预测阻力系数"""
        sp_array = np.atleast_1d(sp)
        
        if method == 'best':
            method = models_data['cd_best_model_name']
        
        cd_models = models_data['cd_models']
        
        if method == 'Polynomial Regression':
            model = cd_models[method][0]
            sp_reshaped = sp_array.reshape(-1, 1)
            cd = model.predict(sp_reshaped)
        elif method == 'Cubic Spline':
            spline = cd_models[method][0]
            cd = spline(sp_array)
        elif method == 'Parametric Model':
            params = cd_models[method][0]
            cd = cd_model(sp_array, *params)
        else:
            raise ValueError(f"Unknown method: {method}")
        
        return cd[0] if len(cd) == 1 else cd
    
    def loaded_predict_cm(sp, method='best'):
        """使用加载的模型预测力矩系数"""
        sp_array = np.atleast_1d(sp)
        
        if method == 'best':
            method = models_data['cm_best_model_name']
        
        cm_models = models_data['cm_models']
        
        if method == 'Polynomial Regression':
            model = cm_models[method][0]
            sp_reshaped = sp_array.reshape(-1, 1)
            cm = model.predict(sp_reshaped)
        elif method == 'Cubic Spline':
            spline = cm_models[method][0]
            cm = spline(sp_array)
        elif method == 'Parametric Model':
            params = cm_models[method][0]
            cm = cm_model(sp_array, *params)
        else:
            raise ValueError(f"Unknown method: {method}")
        
        return cm[0] if len(cm) == 1 else cm
    
    return loaded_predict_cd, loaded_predict_cm, models_data

print("\nCalibration complete. Use predict_cd() and predict_cm() functions for predictions.")

# 保存模型
save_best_models("calibration_models.pkl")

print("\n--- 导出预测函数 ---")
print("现在您可以直接导入预测函数:")
print("from calibration.calibration_draw import best_predict_cd, best_predict_cm")
print("cd = best_predict_cd(sp_value)")
print("cm = best_predict_cm(sp_value)")