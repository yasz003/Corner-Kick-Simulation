"""
Soccer ball physics simulation for corner kicks.
"""
import numpy as np
from scipy.integrate import solve_ivp
from config import BALL_MASS, BALL_RADIUS, BALL_AREA, GRAVITY, AIR_DENSITY, FIELD_LENGTH, FIELD_WIDTH, GOAL_WIDTH, GOAL_HEIGHT, TARGET_RADIUS

def simulate_corner_kick(ball_speed, theta, phi, omega, predict_cd_func=None, predict_cm_func=None, visualize=False):
    """
    Simulate a corner kick with the given parameters and determine
    if it results in a goal near the goalpost.
    
    Args:
        ball_speed: Initial speed (m/s)
        theta: Elevation angle (degrees)
        phi: Horizontal angle (degrees)
        omega: Angular velocity vector (rad/s)
        predict_cd_func: Function to predict drag coefficient based on spatial parameter
        predict_cm_func: Function to predict moment coefficient based on spatial parameter
        visualize: Whether to create visualization
    
    Returns:
        Tuple (is_goal, is_near_post, flight_time, min_distance, goal_position) or
        Tuple (x, y, z, is_goal, is_near_post, flight_time, goal_position) if visualize=True
    """
    # 验证必须提供校准函数
    if predict_cd_func is None or predict_cm_func is None:
        raise ValueError("必须提供阻力系数(cd)和力矩系数(cm)的预测函数")
    
    # 在函数开始处初始化变量
    is_near_post = False
    goal_position = None
    
    # Left and right goalpost positions
    left_post_position = np.array([0, -GOAL_WIDTH/2, 0])
    right_post_position = np.array([0, GOAL_WIDTH/2, 0])
    
    # Initial position (corner)
    ball_position = [0, -FIELD_WIDTH/2, 0]
    
    # Calculate initial velocity components
    vy = ball_speed * np.cos(np.radians(theta)) * np.cos(np.radians(phi))  # Inward
    vx = ball_speed * np.cos(np.radians(theta)) * np.sin(np.radians(phi))  # Forward
    vz = ball_speed * np.sin(np.radians(theta))  # Upward
    
    # Ball velocity array
    ball_velocity = [vx, vy, vz]
    
    # Initial conditions
    states0 = ball_position + ball_velocity
    
    # Time settings
    time = np.linspace(0, MAX_TIME, int(MAX_TIME/TIME_STEP))  # Time array
    
    def ball_dynamics(t, states):
        """Ball dynamics considering drag and Magnus forces with calibrated coefficients"""
        # Extract position and velocity components
        x, y, z, dx, dy, dz = states
        
        # Calculate speed
        v = np.sqrt(dx**2 + dy**2 + dz**2)  # Speed [m/s]
        
        # Initialize accelerations
        ax, ay, az = 0, 0, -GRAVITY  # Start with gravity
        
        if v > 0:
            # Unit velocity vector
            v_unit = np.array([dx, dy, dz]) / v
            
            # 计算空间参数 (spatial parameter)
            omega_vector = np.array(omega)
            omega_magnitude = np.linalg.norm(omega_vector)
            if omega_magnitude > 0 and v > 0:
                sp = (omega_magnitude * BALL_RADIUS) / v  # 空间参数计算公式
            else:
                sp = 0.0
                
            # 使用校准函数获取阻力系数和力矩系数
            c_d = predict_cd_func(sp)
            c_m = predict_cm_func(sp)  # 注意是cm而不是cL
            
            # Drag force (normalized by mass for acceleration)
            drag_acc = -0.5 * AIR_DENSITY * BALL_AREA * c_d * v**2 * v_unit / BALL_MASS
            
            # Magnus force (spin effect)
            velocity = np.array([dx, dy, dz])
            cross_val = np.cross(velocity, omega_vector)
            if np.linalg.norm(cross_val) > 0:
                magnus_unit = cross_val / np.linalg.norm(cross_val)
                magnus_acc = 0.5 * AIR_DENSITY * BALL_AREA * c_m * v**2 * magnus_unit / BALL_MASS
            else:
                magnus_acc = np.zeros(3)
            
            # Add to total acceleration
            ax += drag_acc[0] + magnus_acc[0]
            ay += drag_acc[1] + magnus_acc[1]
            az += drag_acc[2] + magnus_acc[2]
        
        return [dx, dy, dz, ax, ay, az]
    
    def event_ball_ground(t, y):
        """Terminate when ball touches the ground (z=0)"""
        z_pos = y[2]
        return z_pos
    
    def event_ball_goal(t, y):
        """Terminate when ball crosses goal line at appropriate height"""
        x_pos, y_pos, z_pos = y[0], y[1], y[2]
        # Check if ball is at the goal line (x=0)
        if abs(x_pos) < 0.1:  # Small tolerance for numerical issues
            # Check if within goal width and height
            if abs(y_pos) < GOAL_WIDTH/2 and z_pos < GOAL_HEIGHT and z_pos > 0:
                return 0
        return 1
    
    # Set termination conditions
    event_ball_ground.terminal = True
    event_ball_ground.direction = -1
    event_ball_goal.terminal = True
    
    # Solve the ODE
    sol = solve_ivp(
        ball_dynamics, 
        [0, MAX_TIME], 
        states0, 
        method='RK45',
        t_eval=time,
        events=[event_ball_ground, event_ball_goal],
        rtol=1e-6
    )
    
    # Extract solution
    t_sol = sol.t
    x = sol.y[0]
    y = sol.y[1]
    z = sol.y[2]
    
    # Check if it's a goal (if the trajectory terminates due to the goal event)
    is_goal = len(sol.t_events[1]) > 0
    
    # Get goal position if it's a goal
    if is_goal:
        # Get the position where the ball crosses the goal line
        goal_idx = len(x) - 1
        goal_position = np.array([x[goal_idx], y[goal_idx], z[goal_idx]])
        
        # Calculate distance to each goalpost
        dist_left_post = np.linalg.norm(goal_position - left_post_position)
        dist_right_post = np.linalg.norm(goal_position - right_post_position)
        
        # Check if it's in the target area on the inside of the goalpost
        is_near_left = (dist_left_post <= TARGET_RADIUS) and (goal_position[1] > -GOAL_WIDTH/2)
        is_near_right = (dist_right_post <= TARGET_RADIUS) and (goal_position[1] < GOAL_WIDTH/2)
        
        is_near_post = is_near_left or is_near_right
    
    # Flight time until termination
    flight_time = t_sol[-1]
    
    # Calculate minimum distance to goal center
    # Goal center is at (0, 0, goal_height/2)
    goal_center = np.array([0, 0, GOAL_HEIGHT/2])
    
    # Calculate distances from each point of the trajectory to goal center
    distances = []
    for i in range(len(x)):
        point = np.array([x[i], y[i], z[i]])
        dist = np.linalg.norm(point - goal_center)
        distances.append(dist)
    
    min_distance = min(distances) if distances else float('inf')
    
    # Return visualization data if requested
    if visualize:
        return x, y, z, is_goal, is_near_post, flight_time, goal_position if is_goal else None
    
    return is_goal, is_near_post, flight_time, min_distance, goal_position if is_goal else None