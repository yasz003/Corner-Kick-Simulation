"""
Optimization algorithms for finding optimal corner kick parameters.
"""
import numpy as np
import multiprocessing as mp
import time  # 添加缺失的时间模块
import pickle
import os
from functools import partial
from itertools import product
from config import *
from soccer_physics import simulate_corner_kick
from calibration_draw import best_predict_cd, best_predict_cm, cd_model, cm_model

def load_models_for_process():
    """为每个进程加载模型，解决多进程共享问题"""
    try:
        current_dir = os.path.dirname(os.path.abspath(__file__))
        model_path = os.path.join(current_dir, 'calibration', 'calibration_models.pkl')
        
        with open(model_path, 'rb') as f:
            models_data = pickle.load(f)
            
        # 重建预测函数 - 阻力系数
        def process_predict_cd(sp, method='best'):
            """使用加载的模型预测阻力系数"""
            sp_array = np.atleast_1d(sp)
            
            if method == 'best':
                method = models_data['cd_best_model_name']
            
            cd_models = models_data['cd_models']
            
            if method == 'Polynomial Regression':
                model = cd_models[method][0]
                sp_reshaped = sp_array.reshape(-1, 1)
                cd = model.predict(sp_reshaped)
            elif method == 'Cubic Spline':
                spline = cd_models[method][0]
                cd = spline(sp_array)
            elif method == 'Parametric Model':
                params = cd_models[method][0]
                cd = cd_model(sp_array, *params)
            else:
                raise ValueError(f"Unknown method: {method}")
            
            return cd[0] if len(cd) == 1 else cd
        
        # 重建预测函数 - 力矩系数
        def process_predict_cm(sp, method='best'):
            """使用加载的模型预测力矩系数"""
            sp_array = np.atleast_1d(sp)
            
            if method == 'best':
                method = models_data['cm_best_model_name']
            
            cm_models = models_data['cm_models']
            
            if method == 'Polynomial Regression':
                model = cm_models[method][0]
                sp_reshaped = sp_array.reshape(-1, 1)
                cm = model.predict(sp_reshaped)
            elif method == 'Cubic Spline':
                spline = cm_models[method][0]
                cm = spline(sp_array)
            elif method == 'Parametric Model':
                params = cm_models[method][0]
                cm = cm_model(sp_array, *params)
            else:
                raise ValueError(f"Unknown method: {method}")
            
            return cm[0] if len(cm) == 1 else cm
            
        print("进程已成功加载校准模型")
        return process_predict_cd, process_predict_cm
    except Exception as e:
        print(f"进程加载模型失败: {e}")

def evaluate_kick(params):
    """
    Evaluate a set of kick parameters.
    Returns flight time if goal is scored near goalpost, or penalty + distance if not.
    """
    # Extract parameters from the input array
    ball_speed, theta, phi, omega_z = params
    
    # Convert omega to array format (only z-axis spin for simplicity)
    omega = np.array([0, 0, omega_z])
    
    # Run simulation with these parameters
    result = simulate_corner_kick(ball_speed, theta, phi, omega)
    
    # Extract results (更新以适应新的返回格式)
    is_goal, is_near_post, flight_time, min_distance, _ = result
    
    # Penalty for not scoring
    if not is_goal:
        return 1000 + min_distance  # Large penalty + minimum distance to goal
    
    # Additional penalty if not near the goalpost
    if not is_near_post:
        return 500 + flight_time  # Medium penalty + flight time
    
    # If it's a goal near the goalpost, return the flight time (to minimize)
    return flight_time

# 批量评估函数
def evaluate_batch(param_batch):
    results = []
    for params in param_batch:
        score = evaluate_kick(params)
        results.append((score, params))
    return results

# 修改check_any_goals函数，直接使用导入的最佳函数
def check_any_goals(batch):
    """检查一批参数组合是否产生进球"""
    # 不再需要每个进程加载模型
    
    goal_trajectories = []
    for params in batch:
        ball_speed, theta, phi, omega_z = params
        # 传递预测函数参数
        result = simulate_corner_kick(
            ball_speed, 
            theta, 
            phi, 
            np.array([0, 0, omega_z]),
            predict_cd_func=best_predict_cd,  # 使用直接导入的最佳函数
            predict_cm_func=best_predict_cm   # 使用直接导入的最佳函数
        )
        is_goal = result[0]
        is_near_post = result[1]
        flight_time = result[2]
        goal_position = result[4]
        
        if is_goal:
            score = 500 + flight_time if not is_near_post else flight_time
            goal_trajectories.append((score, params, is_near_post, goal_position))
            
    return goal_trajectories

def optimize_corner_kick_parameters():
    """
    Optimize the parameters of a soccer corner kick to score an Olympic goal
    near the goalpost in minimum time.
    
    Returns:
        Tuple: (optimal_parameters, goal_data)
    """
    from visualization import create_visualization
    
    print("Starting optimization. This may take several minutes...")
    start_time = time.time()
    
    # 创建参数网格
    speeds = np.linspace(PARAMETER_BOUNDS[0][0], PARAMETER_BOUNDS[0][1], N_SPEED)
    thetas = np.linspace(PARAMETER_BOUNDS[1][0], PARAMETER_BOUNDS[1][1], N_THETA)
    phis = np.linspace(PARAMETER_BOUNDS[2][0], PARAMETER_BOUNDS[2][1], N_PHI)
    omegas = np.linspace(PARAMETER_BOUNDS[3][0], PARAMETER_BOUNDS[3][1], N_OMEGA)
    
    # 创建所有参数组合
    all_combinations = list(product(speeds, thetas, phis, omegas))
    
    # 将参数组合分成32个批次
    batch_size = len(all_combinations) // 32 + (1 if len(all_combinations) % 32 else 0)
    batches = [all_combinations[i:i+batch_size] for i in range(0, len(all_combinations), batch_size)]
    
    # 跳过第一阶段，直接执行第二阶段
    all_goal_trajectories = []
    
    # 直接开始搜索任意进球
    print("Skipping near-goalpost search. Starting direct search for any goals...")
    print(f"Starting parallel search for any goals with {len(batches)} batches...")
    with mp.Pool(processes=32) as pool:
        goal_batch_results = pool.map(check_any_goals, batches)
    
    # 合并结果
    for batch_result in goal_batch_results:
        all_goal_trajectories.extend(batch_result)
    
    if not all_goal_trajectories:
        print("No successful goals found at all. Try expanding the parameter bounds.")
        return None
    
    end_time = time.time()
    print(f"Optimization completed in {end_time - start_time:.2f} seconds")
    
    # Sort all goal trajectories by flight time
    all_goal_trajectories.sort()
    
    # Select trajectories with sufficient time difference
    selected_trajectories = []
    score, params, _, _ = all_goal_trajectories[0]  # 解包成正确的元素数量
    selected_trajectories.append((score, params))   # 只保留需要的元素
    # Find 2 more trajectories that are sufficiently different
    for score, params,_,_ in all_goal_trajectories[1:]:
        # Check if this trajectory is different enough from all selected ones
        if all(abs(score - prev_score) >= MIN_TIME_DIFF for prev_score, _ in selected_trajectories):
            selected_trajectories.append((score, params))
            
        # Stop once we have 3
        if len(selected_trajectories) >= 3:
            break
    
    # If we couldn't find 3 sufficiently different ones, relax the constraint
    if len(selected_trajectories) < 3:
        print(f"Could not find 3 trajectories with time difference >= {MIN_TIME_DIFF}s")
        print("Taking the fastest available trajectories instead")
        # Just take the fastest trajectories
        selected_trajectories = all_goal_trajectories[:min(3, len(all_goal_trajectories))]
    
    # Print results
    near_post_count = sum(1 for score, _ in selected_trajectories if score < 500)
    print(f"\nTotal goals found: {len(all_goal_trajectories)}")
    print(f"Goals near goalposts: {near_post_count} out of {len(selected_trajectories)} selected")
    print("\nTop 3 Trajectories:")
    trajectories = []
    goal_data = []  # 用于存储所有进球数据
    
    for i, (score, params) in enumerate(selected_trajectories):
        ball_speed, theta, phi, omega_z = params
        optimal_omega = np.array([0, 0, omega_z])
        
        # 输出当前轨迹参数
        print(f"\nTrajectory {i+1}:")
        print(f"Flight Time: {score if score < 500 else score-500:.6f} s")
        print(f"Near Goalpost: {'Yes' if score < 500 else 'No'}")
        print(f"Ball Speed: {ball_speed:.2f} m/s")
        print(f"Elevation Angle (theta): {theta:.2f} degrees")
        print(f"Horizontal Angle (phi): {phi:.2f} degrees")
        print(f"Spin Rate (omega_z): {omega_z:.2f} rad/s")
        
        # Run the simulation with these parameters and save trajectory
        x, y, z, is_goal, is_near_post, flight_time, goal_position = simulate_corner_kick(
            ball_speed, theta, phi, optimal_omega, 
            predict_cd_func=best_predict_cd,  # 添加这行
            predict_cm_func=best_predict_cm,  # 添加这行
            visualize=True
        )
        
        # 如果是进球，记录相关数据
        if is_goal and goal_position is not None:
            goal_data.append({
                'ball_speed': ball_speed,
                'theta': theta,
                'phi': phi,
                'omega_z': omega_z,
                'y_pos': goal_position[1],
                'z_pos': goal_position[2],
                'is_near_post': is_near_post
            })
        
        trajectories.append({
            'params': params,
            'data': (x, y, z, is_goal, is_near_post, flight_time),
            'score': score
        })
    
    # Visualize top 3 trajectories
    create_visualization(trajectories)
    
    # 收集所有进球数据，不仅是前3个轨迹
    # 遍历所有找到的进球轨迹
    print("\n收集所有进球数据...")
    for score, params, is_near_post, goal_position in all_goal_trajectories:
        ball_speed, theta, phi, omega_z = params
        
        # 不再需要重复模拟，直接使用已有的goal_position和is_near_post
        if goal_position is not None and not any(
            abs(g['ball_speed'] - ball_speed) < 0.01 and 
            abs(g['theta'] - theta) < 0.01 and 
            abs(g['phi'] - phi) < 0.01 and 
            abs(g['omega_z'] - omega_z) < 0.01 
            for g in goal_data
        ):
            # 避免重复添加相同参数的进球数据
            goal_data.append({
                'ball_speed': ball_speed,
                'theta': theta,
                'phi': phi,
                'omega_z': omega_z,
                'y_pos': goal_position[1],
                'z_pos': goal_position[2],
                'is_near_post': is_near_post
            })
    
    print(f"共收集了{len(goal_data)}个不同进球的位置数据")
    
    if len(selected_trajectories) == 0:
        return None
    
    return [result[1] for result in selected_trajectories], goal_data