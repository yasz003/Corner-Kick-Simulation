"""
Optimization algorithms for finding optimal corner kick parameters.
"""
import numpy as np
import multiprocessing as mp
import time  # 添加缺失的时间模块
from functools import partial
from itertools import product
from config import *
from soccer_physics import simulate_corner_kick

def evaluate_kick(params):
    """
    Evaluate a set of kick parameters.
    Returns flight time if goal is scored near goalpost, or penalty + distance if not.
    """
    # Extract parameters from the input array
    ball_speed, theta, phi, omega_z = params
    
    # Convert omega to array format (only z-axis spin for simplicity)
    omega = np.array([0, 0, omega_z])
    
    # Run simulation with these parameters
    result = simulate_corner_kick(ball_speed, theta, phi, omega)
    
    # Extract results
    is_goal, is_near_post, flight_time, min_distance = result
    
    # Penalty for not scoring
    if not is_goal:
        return 1000 + min_distance  # Large penalty + minimum distance to goal
    
    # Additional penalty if not near the goalpost
    if not is_near_post:
        return 500 + flight_time  # Medium penalty + flight time
    
    # If it's a goal near the goalpost, return the flight time (to minimize)
    return flight_time

# 批量评估函数
def evaluate_batch(param_batch):
    results = []
    for params in param_batch:
        score = evaluate_kick(params)
        results.append((score, params))
    return results

# 将check_any_goals移到外部作为全局函数，解决pickle问题
def check_any_goals(param_batch):
    results = []
    for params in param_batch:
        ball_speed, theta, phi, omega_z = params
        # 直接运行模拟检查
        result = simulate_corner_kick(ball_speed, theta, phi, np.array([0, 0, omega_z]))
        is_goal = result[0]
        flight_time = result[2]
        if is_goal:
            results.append((500 + flight_time, params))
    return results

def optimize_corner_kick_parameters():
    """
    Optimize the parameters of a soccer corner kick to score an Olympic goal
    near the goalpost in minimum time.
    
    Returns:
        The optimal parameters and the visualization of the optimal trajectory.
    """
    from visualization import create_visualization
    
    print("Starting optimization. This may take several minutes...")
    start_time = time.time()
    
    # 创建参数网格
    speeds = np.linspace(PARAMETER_BOUNDS[0][0], PARAMETER_BOUNDS[0][1], N_SPEED)
    thetas = np.linspace(PARAMETER_BOUNDS[1][0], PARAMETER_BOUNDS[1][1], N_THETA)
    phis = np.linspace(PARAMETER_BOUNDS[2][0], PARAMETER_BOUNDS[2][1], N_PHI)
    omegas = np.linspace(PARAMETER_BOUNDS[3][0], PARAMETER_BOUNDS[3][1], N_OMEGA)
    
    # 创建所有参数组合
    all_combinations = list(product(speeds, thetas, phis, omegas))
    
    # 将参数组合分成32个批次
    batch_size = len(all_combinations) // 32 + (1 if len(all_combinations) % 32 else 0)
    batches = [all_combinations[i:i+batch_size] for i in range(0, len(all_combinations), batch_size)]
    
    # 并行处理所有批次
    print(f"Starting parallel grid search with {len(batches)} batches...")
    with mp.Pool(processes=32) as pool:
        batch_results = pool.map(evaluate_batch, batches)
    
    # 合并所有结果
    all_goal_trajectories = []
    for batch_result in batch_results:
        for score, params in batch_result:
            if score < 500:  # 如果是在门柱附近的进球
                all_goal_trajectories.append((score, params))
    
    # If no goals found near the goalpost
    if not all_goal_trajectories:
        print("No successful goals found near the goalpost. Checking for any goals...")
        
        # 并行检查任何进球
        print(f"Starting parallel search for any goals with {len(batches)} batches...")
        with mp.Pool(processes=32) as pool:
            goal_batch_results = pool.map(check_any_goals, batches)
        
        # 合并结果
        for batch_result in goal_batch_results:
            all_goal_trajectories.extend(batch_result)
        
        if not all_goal_trajectories:
            print("No successful goals found at all. Try expanding the parameter bounds.")
            return None
    
    end_time = time.time()
    print(f"Optimization completed in {end_time - start_time:.2f} seconds")
    
    # Sort all goal trajectories by flight time
    all_goal_trajectories.sort()
    
    # Select trajectories with sufficient time difference
    selected_trajectories = []
    selected_trajectories.append(all_goal_trajectories[0])  # Always take the fastest
    
    # Find 2 more trajectories that are sufficiently different
    for score, params in all_goal_trajectories[1:]:
        # Check if this trajectory is different enough from all selected ones
        if all(abs(score - prev_score) >= MIN_TIME_DIFF for prev_score, _ in selected_trajectories):
            selected_trajectories.append((score, params))
            
        # Stop once we have 3
        if len(selected_trajectories) >= 3:
            break
    
    # If we couldn't find 3 sufficiently different ones, relax the constraint
    if len(selected_trajectories) < 3:
        print(f"Could not find 3 trajectories with time difference >= {MIN_TIME_DIFF}s")
        print("Taking the fastest available trajectories instead")
        # Just take the fastest trajectories
        selected_trajectories = all_goal_trajectories[:min(3, len(all_goal_trajectories))]
    
    # Print results
    near_post_count = sum(1 for score, _ in selected_trajectories if score < 500)
    print(f"\nTotal goals found: {len(all_goal_trajectories)}")
    print(f"Goals near goalposts: {near_post_count} out of {len(selected_trajectories)} selected")
    print("\nTop 3 Trajectories:")
    trajectories = []
    
    for i, (score, params) in enumerate(selected_trajectories):
        ball_speed, theta, phi, omega_z = params
        optimal_omega = np.array([0, 0, omega_z])
        
        print(f"\nTrajectory {i+1}:")
        print(f"Flight Time: {score if score < 500 else score-500:.6f} s")
        print(f"Near Goalpost: {'Yes' if score < 500 else 'No'}")
        print(f"Ball Speed: {ball_speed:.2f} m/s")
        print(f"Elevation Angle (theta): {theta:.2f} degrees")
        print(f"Horizontal Angle (phi): {phi:.2f} degrees")
        print(f"Spin Rate (omega_z): {omega_z:.2f} rad/s")
        
        # Run the simulation with these parameters and save trajectory
        x, y, z, is_goal, is_near_post, flight_time = simulate_corner_kick(
            ball_speed, theta, phi, optimal_omega, visualize=True
        )
        
        trajectories.append({
            'params': params,
            'data': (x, y, z, is_goal, is_near_post, flight_time),
            'score': score
        })
    
    # Visualize top 3 trajectories
    create_visualization(trajectories)
    
    return [result[1] for result in selected_trajectories]