# 在轨迹模拟函数中添加

def simulate_trajectory(initial_params):
    # ...现有代码...
    
    for t in np.arange(0, MAX_TIME, TIME_STEP):
        # ...现有的模拟步骤...
        
        # 早停条件:如果球已经明显偏离目标区域或落地
        if position[2] < 0 or is_clearly_missing_target(position, velocity):
            return {"success": False, "distance": large_penalty_value}
            
        # ...继续模拟...